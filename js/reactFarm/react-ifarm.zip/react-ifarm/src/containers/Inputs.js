import React, { Component } from 'react';
class Inputs extends Component{
    render(){
        return this.props.children
    }
}
export  default Inputs;