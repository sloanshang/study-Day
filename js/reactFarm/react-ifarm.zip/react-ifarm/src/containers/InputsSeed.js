import React, { Component } from 'react';
class InputsSeed extends Component{
    render(){
        return this.props.children
    }
}
export  default InputsSeed;