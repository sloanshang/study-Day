import React, { Component } from 'react';
class InputsSeedMother extends Component{
    render(){
        return this.props.children
    }
}
export  default InputsSeedMother;