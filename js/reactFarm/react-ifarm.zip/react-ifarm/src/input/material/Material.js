import React, { Component } from 'react';
class Material extends Component{
    render(){
        return this.props.children
    }
}
export  default Material;