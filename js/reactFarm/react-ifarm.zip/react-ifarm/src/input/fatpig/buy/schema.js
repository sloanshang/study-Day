export const pregnancyCheckFormSchema=[
     {"k":"f0","n":"出生日期","v":"","type":"date"},
      {"k":"f1","n":"转出农场","v":"","type":"dropDownList"},
      {"k":"f2","n":"品种","v":"" ,"type":"multiSelect"},
      {"k":"f3","n":"性别","v":""},
      {"k":"f4","n":"耳号","v":""},
      {"k":"f5","n":"父亲信息","v":""},
      {"k":"f6","n":"母亲信息","v":""},
      {"k":"f7","n":"重量","v":""},
      ]
