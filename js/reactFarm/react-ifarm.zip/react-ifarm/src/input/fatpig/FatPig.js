import React, { Component } from 'react';
class FatPig extends Component{
    render(){
        return this.props.children
    }
}
export  default FatPig;