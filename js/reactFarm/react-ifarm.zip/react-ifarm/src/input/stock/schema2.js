export const schema2=[
     {"k":"f0","n":"出生日期","v":"","type":"date"},
      {"k":"f1","n":"转出农场","v":"","type":"dropDownList"},
      {"k":"f2","n":"品种","v":"" ,"type":"multiSelect"},
      {"k":"f3","n":"性别","v":""},

      ]
