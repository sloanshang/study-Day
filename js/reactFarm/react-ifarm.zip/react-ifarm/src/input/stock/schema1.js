export const schema1=[
     {"k":"f0","n":"出生日期","v":"","type":"date"},
      {"k":"f1","n":"转出农场","v":"","type":"dropDownList"},

      ]
