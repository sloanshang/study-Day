export const pregnancyCheckFormSchema=[
 {"k":"f0","n":"日期","v":"","type":"date"},
 {"k":"f1","n":"母猪耳号","v":"","type":"dropDownList"},
 {"k":"f2","n":"断奶原因","v":"" },
 {"k":"f3","n":"公头数","v":""},
 {"k":"f4","n":"母头数","v":""},
{"k":"f5","n":"总头数","v":""},
{"k":"f6","n":"小猪品种","v":""}  
 ]
