import dialog from './dialog'
import showConfirm from './Confirm'
export {dialog ,showConfirm}
