export const BASIC_URL = ''
export const PAGE_SIZE =2
export const WIDTH = document.documentElement.clientWidth
export const HEIGHT = document.documentElement.clientHeight
export const BLUE_COLOR='#00F'
