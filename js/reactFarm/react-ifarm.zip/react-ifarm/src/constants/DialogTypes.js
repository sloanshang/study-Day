export const DIALOG_hybirdize='DIALOG_hybirdize'
export const dialogStyle={overlay:{backgroundColor:'rgba(0,0,0,0.7)'}, content: {left:'10%',right:'10%',top:'40%',bottom:'40%'} }