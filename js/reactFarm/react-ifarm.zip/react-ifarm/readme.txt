http://wxaj.shdev.cpchina.cn/api/chart/charts?farm_code=641002-0-0
